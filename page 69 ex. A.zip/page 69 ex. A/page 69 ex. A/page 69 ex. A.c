﻿// page 69 ex. A.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <stdio.h>

//page 69 ex. A

//הפלט הוא: k=4
int main()
{
	int i = 2, j = 3, k = 0;
	switch (i < j)
	{
	case 0:k++;
		break;
	case 1: k += 5;
	default: k--;
		break;
	}
	printf("k=%d\n", k);
}

